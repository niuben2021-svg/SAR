"""SAR-VLM MVP package."""
